# Images folder

This build ships with **no photos** — every image spot on the site (hero, gallery,
room cards) is currently a styled placeholder tile drawn with CSS so the layout
works immediately without any files here.

To add your real photography:

1. Drop your images into this folder, e.g. `assets/images/hero.jpg`,
   `assets/images/gallery-living-1.jpg`, `assets/images/room-pearl-suite.jpg`.
2. In `index.html`, find the placeholder element you want to replace
   (search for `class="ph"`) and swap it for a real `<img>` tag, e.g.:

   ```html
   <!-- before -->
   <div class="ph tall rv" role="img" aria-label="Pearl White living space with natural light">Living space, morning light</div>

   <!-- after -->
   <img class="tall rv" src="assets/images/living-room.jpg"
        alt="Pearl White living space with natural light"
        style="border-radius:26px;object-fit:cover;width:100%;height:100%">
   ```
3. Recommended sizes for a crisp, fast-loading site:
   - Hero background (if you add one): 1920×1080px, compressed to under 400KB
   - Gallery photos: 1200×900px
   - Room/accommodation cards: 1000×750px
4. Compress images before uploading (e.g. with squoosh.app or TinyPNG) to keep
   the site fast on mobile.
