const $=s=>document.querySelector(s);
const stays=[
 {n:"The Pearl Suite",g:2,b:"1 king bed",ba:"1 private bath",a:"Air conditioning · Smart TV · Wi-Fi",p:4500},
 {n:"The Ivory House",g:4,b:"2 queen beds",ba:"1.5 baths",a:"Full kitchen · Pool access · Parking",p:7200},
 {n:"The Full Estate",g:8,b:"4 beds",ba:"3 baths",a:"Whole property · Pool · Outdoor space",p:12500}
];
const cats=["Living Spaces","Bedrooms","Kitchen","Bathroom","Outdoor Area","Amenities"];
const am=["Wi-Fi","Air Conditioning","Smart TV","Fully Equipped Kitchen","Comfortable Beds","Hot Shower","Private Parking","Swimming Pool","Outdoor Space","Work-Friendly Area","Towels & Linens","Essential Toiletries"];
const peso=n=>"₱"+n.toLocaleString();
// selects
["#hg","#bg"].forEach(id=>{$(id).innerHTML=Array.from({length:8},(_, i)=>`<option value="${i+1}">${i+1} guest${i?"s":""}</option>`).join("")});
$("#bs").innerHTML=stays.map((s,i)=>`<option value="${i}">${s.n} (up to ${s.g})</option>`).join("");
$("#acc").innerHTML=stays.map(s=>`<div class="card acc rv"><div class="ph" role="img" aria-label="${s.n} at Pearl White">${s.n}</div><div class="b"><h3>${s.n}</h3><div class="meta">Sleeps ${s.g} · ${s.b} · ${s.ba}</div><p>${s.a}</p><div class="price">From ${peso(s.p)} <small style="font:300 .9rem Jost">/ night</small></div><a class="btn ghost" href="#book" onclick="$('#bs').value=${stays.indexOf(s)}">View Details</a></div></div>`).join("");
$("#am").innerHTML=am.map(a=>`<div class="rv"><i>${a[0]}</i>${a}</div>`).join("");
// gallery
const shots=[];cats.forEach(c=>{for(let i=1;i<=3;i++)shots.push({c,t:`${c} ${i}`})});
$("#grid").innerHTML=shots.map((s,i)=>`<button class="ph" data-i="${i}" data-c="${s.c}" aria-label="Open ${s.t}">${s.t}</button>`).join("");
$("#tabs").innerHTML=["All",...cats].map((c,i)=>`<button class="${i?"":"on"}">${c}</button>`).join("");
$("#tabs").onclick=e=>{if(e.target.tagName!="BUTTON")return;[...$("#tabs").children].forEach(b=>b.classList.toggle("on",b==e.target));document.querySelectorAll("#grid .ph").forEach(p=>p.classList.toggle("hide",e.target.textContent!="All"&&p.dataset.c!=e.target.textContent))};
let cur=0;const show=i=>{cur=(i+shots.length)%shots.length;$("#li").textContent=shots[cur].t;$("#lb").classList.add("open")};
$("#grid").onclick=e=>{const b=e.target.closest(".ph");if(b)show(+b.dataset.i)};
$("#lx").onclick=()=>$("#lb").classList.remove("open");$("#lp").onclick=()=>show(cur-1);$("#ln").onclick=()=>show(cur+1);
document.onkeydown=e=>{if(!$("#lb").classList.contains("open"))return;if(e.key=="Escape")$("#lx").click();if(e.key=="ArrowLeft")show(cur-1);if(e.key=="ArrowRight")show(cur+1)};
// nav
$("#burger").onclick=()=>{const o=$("#menu").classList.toggle("open");$("#burger").setAttribute("aria-expanded",o)};
$("#menu").onclick=()=>$("#menu").classList.remove("open");
// dates
const iso=d=>d.toISOString().slice(0,10),today=iso(new Date());
["#hin","#hout","#bin","#bout"].forEach(id=>$(id).min=today);
// mock booked ranges (owner: replace with real calendar / booking platform sync)
const blocked=[["2026-10-10","2026-10-13"]];
const HOST_EMAIL="aljoncervantes99@gmail.com"; // owner: the inbox that receives booking requests
const HOST_WHATSAPP="639518232858"; // owner: your WhatsApp number, digits only with country code
$("#footer-email").textContent=HOST_EMAIL;
if(HOST_WHATSAPP)$("#footer-wa").innerHTML=` · <a href="https://wa.me/${HOST_WHATSAPP}" target="_blank" rel="noopener" style="color:inherit">WhatsApp</a>`;
let lastCheck=null;
function check(inV,outV,g,si,fromHero){
 const m=$("#bmsg");m.className="msg";
 if(!inV||!outV){return err("Choose both check-in and check-out dates.")}
 const a=new Date(inV),b=new Date(outV),n=Math.round((b-a)/864e5);
 if(n<1)return err("Check-out must be after check-in.");
 const s=stays[si];
 if(g>s.g)return err(`${s.n} sleeps up to ${s.g} guests. Choose a larger option or fewer guests.`);
 if(blocked.some(([x,y])=>inV<y&&outV>x))return err("Those dates are taken. Try nearby dates or contact the host.");
 lastCheck={si,n,inV,outV,g,total:s.p*n};
 m.className="msg ok";m.innerHTML=`<b style="font-weight:500">Available.</b> ${s.n}, ${n} night${n>1?"s":""} · ${peso(s.p*n)} total (${peso(s.p)} / night). Add your details below to send a request.`;
 $("#req").style.display="block";
 if(fromHero)$("#book").scrollIntoView();
 function err(t){lastCheck=null;m.className="msg err";m.textContent=t;$("#req").style.display="none";if(fromHero)$("#book").scrollIntoView()}
}
$("#bcheck").onclick=()=>check($("#bin").value,$("#bout").value,+$("#bg").value,+$("#bs").value);
$("#hcheck").onclick=()=>{$("#bin").value=$("#hin").value;$("#bout").value=$("#hout").value;$("#bg").value=$("#hg").value;const g=+$("#hg").value;let si=stays.findIndex(s=>s.g>=g);check($("#hin").value,$("#hout").value,g,$("#bs").value=si<0?2:si,true)};
function mailtoLink(o){
 const subj=encodeURIComponent(`New Pearl White booking request – ${o.stay}, ${o.inV} to ${o.outV}`);
 const body=encodeURIComponent(`New booking request from the Pearl White website:\n\nGuest: ${o.name}\nEmail: ${o.email}\nPhone: ${o.phone||"-"}\nAccommodation: ${o.stay}\nGuests: ${o.g}\nCheck-in: ${o.inV}\nCheck-out: ${o.outV}\nEstimated total: ${o.total}\nMessage: ${o.msg||"-"}`);
 return `mailto:${HOST_EMAIL}?subject=${subj}&body=${body}`;
}
function waLink(o){
 const text=encodeURIComponent(`New Pearl White booking request\n\nGuest: ${o.name}\nEmail: ${o.email}\nPhone: ${o.phone||"-"}\nAccommodation: ${o.stay}\nGuests: ${o.g}\nCheck-in: ${o.inV}\nCheck-out: ${o.outV}\nEstimated total: ${o.total}\nMessage: ${o.msg||"-"}`);
 return `https://wa.me/${HOST_WHATSAPP}?text=${text}`;
}
$("#req").onsubmit=e=>{e.preventDefault();const m=$("#bmsg");
 if(!$("#nm").value.trim()||!/^\S+@\S+\.\S+$/.test($("#em").value)){m.className="msg err";m.textContent="Enter your name and a valid email address.";return}
 if(!lastCheck){m.className="msg err";m.textContent="Please check availability again before sending your request.";return}
 const o={name:$("#nm").value.trim(),email:$("#em").value.trim(),phone:$("#ph").value.trim(),stay:stays[lastCheck.si].n,g:lastCheck.g,inV:lastCheck.inV,outV:lastCheck.outV,total:peso(lastCheck.total),msg:$("#nt").value.trim()};
 const wa=HOST_WHATSAPP?`<a class="btn" style="margin-right:.6rem" href="${waLink(o)}" target="_blank" rel="noopener">Send via WhatsApp</a>`:`<span style="color:var(--taupe);font-size:.9rem">WhatsApp isn't connected yet</span>`;
 m.className="msg ok";m.innerHTML=`Thank you, ${o.name}. Choose how to send this request to the host:<br><div style="margin-top:.8rem">${wa}<a class="btn ghost" href="${mailtoLink(o)}">Send via Email</a></div><p style="margin-top:.8rem;font-size:.9rem">The host will reply to ${o.email} within 24 hours.</p>`;
 $("#req").style.display="none";
};
// reveal
const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target)}}),{threshold:.12});
document.querySelectorAll(".rv").forEach(x=>io.observe(x));
